﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace appSubtracao
{
    public partial class appSubtracao : Form
    {
        public appSubtracao()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            float nmr1 = float.Parse(txtnum1)

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnmais_Click(object sender, EventArgs e)
        {

        }
    }
}
